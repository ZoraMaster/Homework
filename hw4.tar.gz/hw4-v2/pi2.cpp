// C++ code to implement computation of pi using one-sided communication with fencing
#include <bits/stdc++.h>
#include <stdio.h>
#include <math.h>
#include <mpi.h>
using namespace std;

// Function to calculate PI
long double calcPI(long double PI, long double n, long double sign, long double iterations, int rank)
{
    // Add for (iterations)
    for (unsigned long int i = 0; i <= iterations; i++) {
        PI = PI + (sign * (4 / ((n) * (n + 1) * (n + 2))));
        // Add and sub
        // alt sequences
        sign = sign * (-1);
        // Increment by 2 according to Nilkantha’s formula
        n += 2;
    }

    // Return the value of Pi
    return PI;
}

// main
int main(int argc, char** argv)
{
    // Initialize MPI
    MPI_Init(&argc, &argv);

    // Get the rank and size of the MPI communicator
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    // Initialise variables, require/accept passed-in value
    auto start = std::chrono::steady_clock::now();  // set timer
    long double PI = 3, n = 2, sign = 1;
    const long double PI25DT = 3.141592653589793238462643383; // set test value for error
    long double cPI = 0.0;

    if (argc==1)
    {
        if (rank == 0) {
            printf("You must pass a single numeric value\n");
            printf("the value should be 100M or higher\n");
        }
        MPI_Finalize();
        return -1;
    }

    long double iterations = std::stod(argv[1]); // set to passed-in numeric value

    // Create a window for shared memory
    MPI_Win win;
    MPI_Win_create(&cPI, sizeof(long double), sizeof(long double), MPI_INFO_NULL, MPI_COMM_WORLD, &win);

    // Perform one-sided communication with fencing
    MPI_Win_fence(0, win);
    cPI = calcPI(PI, n, sign, iterations, rank);
    MPI_Win_fence(0, win);

    // Print the result on rank 0
    if (rank == 0) {
        printf("PI is approx %.50Lf, Error is %.50Lf\n", cPI, fabsl(cPI - PI25DT));
        auto end = std::chrono::steady_clock::now(); // end timer
        auto diff = end - start; // compute time
        std::cout << std::chrono::duration<double, std::milli>(diff).count() << " Runtime ms" << std::endl;
    }

    // Free the window
    MPI_Win_free(&win);

    // Finalize MPI
    MPI_Finalize();

    return 0;
}
