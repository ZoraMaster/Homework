module load openmpi/4.1.1-gcc8.3.1
module load cuda/12.4.0
module load gcc/13.2.1-p20240113
