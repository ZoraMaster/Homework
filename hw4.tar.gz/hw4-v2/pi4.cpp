// C++ code to implement computation of pi using Monte Carlo simulation
#include <iostream>
#include <random>
#include <chrono>

// Function to calculate PI
double calcPI(unsigned long long iterations)
{
    unsigned long long insideCircle = 0;

    // Create a random number generator
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<double> dis(-1.0, 1.0);

    // Use the Monte Carlo simulation to calculate PI
    for (unsigned long long i = 0; i < iterations; i++) {
        double x = dis(gen);
        double y = dis(gen);
        double distance = x * x + y * y;
        if (distance <= 1.0) {
            insideCircle++;
        }
    }

    // Calculate the value of Pi
    double PI = 4.0 * insideCircle / iterations;
    return PI;
}

// main
int main(int argc, char** argv)
{
    // Initialise variables, require/accept passed-in value 
    auto start = std::chrono::steady_clock::now();  // set timer
    const long double PI25DT = 3.141592653589793238462643383; // set test value for error
    
    if (argc==1)
    {
      printf("You must pass a single numeric value\n");
      printf("the value should be 100M or higher\n");
      return -1;
    }

    unsigned long long iterations = std::stod(argv[1]); // set to passed-in numeric value
    double cPI = calcPI(iterations);
    // Function call
    printf("PI is approx %.50Lf, Error is %.50Lf\n", cPI, fabsl(cPI - PI25DT));
    auto end = std::chrono::steady_clock::now(); // end timer
    auto diff = end - start; // compute time
    std::cout << std::chrono::duration<double, std::milli>(diff).count() << " Runtime ms" << std::endl;
    return 0;
}

