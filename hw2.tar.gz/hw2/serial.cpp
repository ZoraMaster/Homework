#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include "common.h"
#include <vector>
#define PARTICLE_GRID_INDEX(p) (int)(floor(p.x / cutoff) * grid_size + floor(p.y / cutoff))
#define density 0.0005
#define cutoff  0.01

int grid_size;
int num_cells;
int *cell_id;
int n; 

class Cell {
public:
    // Counter
    int num_neighbours;
    // Neighbouring cells
    std::vector<int> neighbour_ids;
    // Particles in the cell
    std::vector<int> particle_ids;           

    Cell(): neighbour_ids(9, 0) {
        num_neighbours = 0;
    }
};

// Initialize a grid of cells
void init_cells(Cell *cells) {
    int x, y, i, k, next_x, next_y, new_id;
    int dx[] = {-1, 0, -1, 0, 0, 0, 1, 1, 1};
    int dy[] = {-1, 0, 1, -1, 0, 1, -1, 0, 0};

    // For each cell
    for(i = 0; i < num_cells; ++i) {
        x = i % grid_size;
        y = (i - x) / grid_size;
        // For cell's neighbours
        for(k = 0; k < 9; ++k) {
            next_x = x + dx[k];
            next_y = y + dy[k];
            if (next_x >= 0 && next_y >= 0 && next_x < grid_size && next_y < grid_size) {
                new_id = next_x + next_y * grid_size;
                cells[i].neighbour_ids[cells[i].num_neighbours] = new_id;
                cells[i].num_neighbours++;
            }
        }
    }
    return;
}

// Update the particles in cells to prepare for the next iteration
void griding(Cell *cells) {
    int i, id, idx;
    // Clear particle counter
    for(i = 0; i < num_cells; ++i) {
        cells[i].particle_ids.clear();
    }

    // Set particles into cells
    for(i = 0; i < n; ++i) {
        id = cell_id[i];
        cells[id].particle_ids.push_back(i);
    }
    return;
}

//Apply particle force in each cell
void apply_force_cell(particle_t *particles, Cell *cells, int i, double *dmin, double *davg, int *navg) {
    Cell *cur_cell = cells + i;
    Cell *new_cell;
    int k, j, par_cur, par_nei;

    // For all particles in this cell
    for(i = 0; i < cur_cell->particle_ids.size(); ++i) {
        // Look at the neighbours including itself
        for(k = 0; k < cur_cell->num_neighbours; ++k) {
            new_cell = cells + cur_cell->neighbour_ids[k];
            // For all particles in the neighbour cell
            for(j = 0; j < new_cell->particle_ids.size(); ++j) {
                par_cur = cur_cell->particle_ids[i];
                par_nei = new_cell->particle_ids[j];
                apply_force(particles[par_cur],particles[par_nei],dmin, davg, navg);
            }
        }
    }
    return;
}

int main( int argc, char **argv ) {
    int navg, nabsavg = 0;
    double davg, dmin, absmin = 1.0, absavg = 0.0;

    if( find_option( argc, argv, "-h" ) >= 0 ) {
        printf( "Options:\n" );
        printf( "-h to see this help\n" );
        printf( "-n <int> to set the number of particles\n" );
        printf( "-o <filename> to specify the output file name\n" );
        printf( "-s <filename> to specify a summary file name\n" );
        printf( "-no turns off all correctness checks and particle output\n");
        return 0;
    }

    n = read_int( argc, argv, "-n", 1000 );

    char *savename = read_string( argc, argv, "-o", NULL );
    char *sumname = read_string( argc, argv, "-s", NULL );

    FILE *fsave = savename ? fopen( savename, "w" ) : NULL;
    FILE *fsum = sumname ? fopen ( sumname, "a" ) : NULL;

    particle_t *particles = (particle_t *) malloc(n * sizeof(particle_t));

    set_size(n);

    // Initialize global variables and cells
    grid_size = (int) ceil(sqrt(density * n) / cutoff);
    num_cells = grid_size * grid_size;
    cell_id =  new int[n];
    Cell *cells = new Cell[num_cells];

    // Initialize
    init_cells(cells);
    init_particles(n, particles);

    // Allocate the position of particle to cells
    for(int i = 0; i < n; ++i) {
        move(particles[i]);
        particles[i].ax = particles[i].ay = 0;
        cell_id[i] = PARTICLE_GRID_INDEX(particles[i]);
    }

    // Map the cells back to particles
    griding(cells);

    // Simulate a number of time steps
    double simulation_time = read_timer();

    for(int step = 0; step < NSTEPS; step++) {
        navg = 0;
        davg = 0.0;
        dmin = 1.0;

        // Compute forces
        for(int i = 0; i < n; ++i) {
            particles[i].ax = particles[i].ay = 0;
        }

        for(int i = 0; i < num_cells; ++i) {
            apply_force_cell(particles, cells, i, &dmin, &davg, &navg);
        }

        // Move particles
        for(int i = 0; i < n; ++i) {
            move(particles[i]);
            particles[i].ax = particles[i].ay = 0;
            cell_id[i] = PARTICLE_GRID_INDEX(particles[i]);
        }

        griding(cells);  // Reset number of particles in each cell and calculate again

        if(find_option( argc, argv, "-no" ) == -1) {
            // Computing statistical data
            if(navg) {
                absavg +=  davg/navg;
                nabsavg++;
            }

            if(dmin < absmin) absmin = dmin;
        }
    }
    simulation_time = read_timer() - simulation_time;

    printf( "n = %d, simulation time = %g seconds", n, simulation_time);

    if( find_option( argc, argv, "-no" ) == -1 ) {
        if (nabsavg) absavg /= nabsavg;
        // The minimum distance absmin between 2 particles during the run of the simulation
        // A Correct simulation will have particles stay at greater than 0.4 (of cutoff) with typical values between .7-.8
        // A simulation where particles don't interact correctly will be less than 0.4 (of cutoff) with typical values between .01-.05
        // The average distance absavg is ~.95 when most particles are interacting correctly and ~.66 when no particles are interacting
        printf( ", absmin = %lf, absavg = %lf", absmin, absavg);
        if (absmin < 0.4) printf ("\nThe minimum distance is below 0.4 meaning that some particle is not interacting");
        if (absavg < 0.8) printf ("\nThe average distance is below 0.8 meaning that most particles are not interacting");
    }
    printf("\n");

    // Printing summary data
    if( fsum)
        fprintf(fsum,"%d %g\n", n, simulation_time);

    // Clearing space
    if( fsum )
        fclose( fsum );
    free( particles );
    if( fsave )
        fclose( fsave );

    return 0;
}
