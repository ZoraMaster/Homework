module unload intel
module load gcc
module load openmpi/3.1.6-gcc8.3.1
